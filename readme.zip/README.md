# HEAVENLY — Multipurpose Discord Bot

> A silent, all-knowing guardian watching over your server. Automated protection, divine engagement, and absolute authority.

---

## Features

### 🛡️ Moderation
- `/kick` `/ban` `/unban` `/mute` `/unmute`
- `/warn` `/warnings` `/warnings-clear`
- `/clear` — bulk delete messages

### 🔒 Security
- **Anti-Nuke** — detects mass bans, channel deletes, and role deletes instantly
- **Anti-Raid** — detects join floods and new-account raids, auto-lockdown or kick/ban

### 🤖 Auto-Mod
- Banned word filter
- Mass-mention filter
- Invite link blocker

### 🎉 Giveaways
- `/giveaway create` `/giveaway end` `/giveaway reroll`
- Auto-ends when timer expires

### 💤 AFK System
- `/afk` — marks you as AFK, auto-removes when you return
- Notifies anyone who mentions you while AFK

### 🎭 Reaction Roles
- `/reactionrole add` `/reactionrole remove`
- Users self-assign roles by reacting to messages

### 🏷️ Custom Tags
- `/tag create` `/tag delete` `/tag get` `/tag list`
- Trigger with `!tagname` in chat

### ⚔️ RPG System
- Classes, hunting, shop, inventory, duels, and levelling

### 👋 Welcome / Leave Messages
- Configurable per-guild welcome and leave announcements

### 📋 Other
- Message edit & delete logs
- Autorole — auto-assign a role on member join
- Whitelist — grant users temporary mod access

---

## Setup

### Requirements
- Python 3.8+
- Packages: `discord.py` `aiosqlite` `python-dotenv`

```bash
pip install discord.py aiosqlite python-dotenv
```

### Configuration

1. Clone this repository
```bash
git clone https://github.com/yourusername/heavenly-bot.git
cd heavenly-bot
```

2. Create a `.env` file
```env
DISCORD_TOKEN=your_token_here
```

3. Run the bot
```bash
python multipurpose_bot.py
```

### Discord Developer Portal Settings
- ✅ Server Members Intent
- ✅ Message Content Intent
- ✅ Presence Intent
- Scopes: `bot` + `applications.commands`
- Permissions: `Administrator`

---

## Invite

[Click here to invite HEAVENLY to your server](https://discord.com/oauth2/authorize?client_id=1528008443229634680&permissions=8&scope=bot%20applications.commands)

---

## Database

All data is stored locally in `bot.db` (SQLite). No external database required.

**Tables:** `guild_config`, `warnings`, `mutes`, `banned_words`, `reaction_roles`, `tags`, `rpg_characters`, `whitelist`, `afk`, `giveaways`

---

## Commands (24 total)

| Command | Description |
|---------|-------------|
| `/help` | Show all commands |
| `/kick` | Kick a member |
| `/ban` | Ban a member |
| `/unban` | Unban a user |
| `/mute` | Timeout a member |
| `/unmute` | Remove timeout |
| `/warn` | Warn a member |
| `/warnings` | View warnings |
| `/warnings-clear` | Clear warnings |
| `/clear` | Bulk delete messages |
| `/autorole set` | Set auto-assign role |
| `/afk` | Set AFK status |
| `/giveaway create` | Start a giveaway |
| `/reactionrole add` | Add a reaction role |
| `/tag create` | Create a custom tag |
| `/antinuke setup` | Configure Anti-Nuke |
| `/antiraid setup` | Configure Anti-Raid |
| `/automod toggle` | Toggle Auto-Mod |
| `/welcome set` | Set welcome channel |
| `/leave set` | Set leave channel |
| `/setlogchannel` | Set log channel |
| `/role give` | Give a role to a member |
| `/whitelist add` | Grant temp mod access |
| `/rpg start` | Start your RPG journey |

---

## License

MIT License — free to use, modify, and distribute.
